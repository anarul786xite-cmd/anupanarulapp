# Build APK without installing Android Studio locally

1. Create/sign in to a GitHub account.
2. Create a new repository and upload the contents of this project (not the ZIP itself).
3. Open the repository's **Actions** tab and select **Build Android APK**.
4. Click **Run workflow** and confirm.
5. When the workflow finishes successfully, open that workflow run and download the **AnarulAnup-debug-apk** artifact.
6. Extract the downloaded artifact ZIP to get `app-debug.apk`; copy it to your Android phone and install it. If prompted, allow installing apps from that source.

The APK is a debug build. For public Play Store distribution, make a signed release build.
